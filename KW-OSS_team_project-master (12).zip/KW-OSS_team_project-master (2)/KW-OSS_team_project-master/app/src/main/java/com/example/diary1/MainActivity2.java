package com.example.diary1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    isLogin_check loginCheck;
    TextView textView;
    public ArrayList<String> name=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView=findViewById(R.id.texttext);
        textView.setText("1");

        if(((isLogin_check) getApplication()).getStore_name().isEmpty()){
            textView.setText("비어있습니다");
        }else{
            for(int i=0;i<((isLogin_check) getApplication()).getStore_name().size();i++){
                textView.append((((isLogin_check) getApplication()).getStore_name().get(i)));
            }
        }


    }
}