package com.example.diary1;

import android.app.Application;

import java.util.ArrayList;

public class isLogin_check extends Application {
    char islogin='0';
    String id="비로그인";
    String name="익명";
    ArrayList<String> store_name=new ArrayList<String>();


    public char getGlobalValue(){
        return islogin;
    }
    public void setGlobalValue(char mValue){
        this.islogin=mValue;
    }
    public String getId(){return id;}
    public void setId(String name){this.id=name;}
    public String getName(){return name;}
    public void setName(String name){this.name=name;}
    public void setStore_name(ArrayList<String> store_name){this.store_name=store_name;}
    public ArrayList<String> getStore_name(){
        return this.store_name;
    }
}
