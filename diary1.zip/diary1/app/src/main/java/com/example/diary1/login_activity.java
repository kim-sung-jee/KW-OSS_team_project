package com.example.diary1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class login_activity extends AppCompatActivity {
    TextView registerButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        registerButton=(TextView) findViewById(R.id.registerButton2);
        registerButton.setOnClickListener(new lisnter1());
    }
    class lisnter1 implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Intent RegisterIetent=new Intent(login_activity.this,Register.class);
            login_activity.this.startActivity(RegisterIetent);
        }
    }
}