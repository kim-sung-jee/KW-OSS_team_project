package com.example.diary1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    fragment_pink pinkFragment = new fragment_pink();
    yellow yellowFragment = new yellow();
    blue blueFragment=new blue();
    green greeFragment=new green();
    FragmentManager fragmentManager = getSupportFragmentManager();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        FragmentTransaction transaction = fragmentManager.beginTransaction();
//        transaction.replace(R.id.container, pinkFragment).commitAllowingStateLoss();

        BottomNavigationView bottom_menu = findViewById(R.id.bottom_menu);
        bottom_menu.setOnNavigationItemSelectedListener(new bottomMenuClick());

    }

    class bottomMenuClick implements BottomNavigationView.OnNavigationItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.first_tab:
                    FragmentTransaction f1=getSupportFragmentManager().beginTransaction().replace(R.id.container, pinkFragment);
                    f1.addToBackStack(null);
                    f1.commit();
                    return true;

                case R.id.second_tab:
                    FragmentTransaction f2=getSupportFragmentManager().beginTransaction().replace(R.id.container, yellowFragment);
                    f2.addToBackStack(null);
                    f2.commit();


                    return true;
                case R.id.third_tab:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,blueFragment).commit();
                    return true;
                case R.id.fourth_tab:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container,greeFragment).commit();
                default:
                    return true;
            }
        }
    }


     //옵션 메뉴 구성을 위해 호출하는 메서드
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }
    // 옵션 메뉴의 항목을 터치하면 호출되는 메서드

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //사용자가 선택한 메뉴 항목의 아이디를 추출한다.
        Bundle bundle=new Bundle();
        int id=item.getItemId();
        switch (id){
            case R.id.item1:
                break;
            case R.id.item2:
                Intent item2_intent=new Intent(this,login_activity.class);
                startActivity(item2_intent);
                break;
            case R.id.item3:
                break;
            case R.id.item4:
                break;
        }
        return super.onOptionsItemSelected(item);
    }



}

