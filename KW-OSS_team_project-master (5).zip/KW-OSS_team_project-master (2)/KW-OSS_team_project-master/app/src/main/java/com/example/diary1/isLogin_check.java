package com.example.diary1;

import android.app.Application;

public class isLogin_check extends Application {
    char islogin='0';
    String id="비로그인";
    String name="익명";
    public char getGlobalValue(){
        return islogin;
    }
    public void setGlobalValue(char mValue){
        this.islogin=mValue;
    }
    public String getId(){return id;}
    public void setId(String name){this.id=name;}
    public String getName(){return name;}
    public void setName(String name){this.name=name;}
}
