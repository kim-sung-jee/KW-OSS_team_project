package com.example.diary1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

public class writePage extends AppCompatActivity {

    Button btn_Save;
    EditText editText_TextArea;
    private String fileName_content;
    private String fileName_weather;
    private String fileName_location;
    private String fileName_title;
    private String fileName_image;

    Button btn_select;
    private long backPressTime = 0;
    ImageView imageView;
    Bitmap forImage;

    TextView date;
    EditText weather;
    EditText location;
    EditText title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_page);

        // 액티비티간 데이터 전달
        date=(TextView) findViewById(R.id.textView13);
        Intent secondIntent=getIntent();
        String m=secondIntent.getStringExtra("Date");
        date.setText(m);
        imageView=findViewById(R.id.fornoimage_png);


        btn_select=findViewById(R.id.button10);
        btn_Save=(Button) findViewById(R.id.button8);


        btn_select.setOnClickListener(btnSelectListener);
        btn_Save.setOnClickListener(btnSaveListener);

        //btn_Delete.setOnClickListener(btnDeleteListener);

        fileName_image=m+"image";
        fileName_content=m+"content";
        fileName_location=m+"location";
        fileName_weather=m+"weather";
        fileName_title=m+"title";

        editText_TextArea=findViewById(R.id.editText);
        weather=findViewById(R.id.editTextTextPersonName3);
        location=findViewById(R.id.editTextTextPersonName2);
        title=findViewById(R.id.editTextTextPersonName);

    }

    public void selectImage(View view){
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,101);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==101){
            if(resultCode==RESULT_OK){
                Uri fileUri=data.getData();
                ContentResolver resolver=getContentResolver();
                try{
                    InputStream inputStream=resolver.openInputStream(fileUri);
                    Bitmap imgBitmap= BitmapFactory.decodeStream(inputStream);
                    imageView.setImageBitmap(imgBitmap);
                    inputStream.close();
                    forImage=imgBitmap;

                    //Toast.makeText(getApplicationContext(),"파일 불러오기 성공",Toast.LENGTH_LONG).show();

                }catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"실패",Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    public void saveBitmapToJpeg(Bitmap bitmap){
        File tempFile=new File(getCacheDir(),fileName_image);
        try{
            tempFile.createNewFile();
            FileOutputStream out=new FileOutputStream(tempFile);
            bitmap.compress(Bitmap.CompressFormat.PNG,100,out);
            out.close();


        }catch (Exception e){

        }
    }





    View.OnClickListener btnSelectListener=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            isLogin_check lct=(isLogin_check) getApplication();
            Iterator<String> iterator=lct.getFinal_name().iterator();

            PopupMenu popupMenu=new PopupMenu(getApplicationContext(),view);
            Menu menu=popupMenu.getMenu();
            //Toast.makeText(getApplicationContext(),"asd",Toast.LENGTH_LONG).show();
            if(lct.getFinal_name().size()!=0) {
            for (int i = 0; i < lct.getFinal_name().size(); i++) {
                menu.add(0, i, 0, iterator.next());
            }
            }
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    //int i=menuItem.getItemId();
                    location.setText(menuItem.getTitle());
                    return true;
                }
            });



            popupMenu.show();


        }
    };















    //파일 저장 버튼 클릭처리
    View.OnClickListener btnSaveListener = new View.OnClickListener()
    {

        public void onClick(View v) {
            //Toast.makeText(getApplicationContext(), "저장 버튼 클릭 테스트", Toast.LENGTH_LONG).show();
            //파일 저장 시 이용할 파일 출력 스트림
            FileOutputStream outputStream = null;
            FileOutputStream weatherStream = null;
            FileOutputStream locationStream = null;
            FileOutputStream titleStream = null;
            String s1 = editText_TextArea.getText().toString();
            String s2 = weather.getText().toString();
            String s3 = location.getText().toString();
            String s4 = title.getText().toString();

            if (s1.length() == 0 || s2.length() == 0 || s3.length() == 0 || s4.length() == 0) {
                Toast.makeText(getApplicationContext(), "빈칸은 허용하지 않습니다!", Toast.LENGTH_LONG).show();

            } else {
                try {
                    try {
                        saveBitmapToJpeg(forImage);
                    } catch (Exception e) {

                    }
                    outputStream = openFileOutput(fileName_content, MODE_PRIVATE);
                    weatherStream = openFileOutput(fileName_weather, MODE_PRIVATE);
                    locationStream = openFileOutput(fileName_location, MODE_PRIVATE);
                    titleStream = openFileOutput(fileName_title, MODE_PRIVATE);

                    //에디트 박스에 저장된 스트링 데이터를 스트림에 기록함
                    outputStream.write(editText_TextArea.getText().toString().getBytes());
                    outputStream.close();
                    weatherStream.write(weather.getText().toString().getBytes());
                    weatherStream.close();
                    locationStream.write(location.getText().toString().getBytes());
                    locationStream.close();
                    titleStream.write(title.getText().toString().getBytes());
                    titleStream.close();

                    //Toast.makeText(getApplicationContext(), fileName_content+" "+fileName_location, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                finish();
            }
        }
    };

    //파일 삭제 버튼 클릭처리
//    View.OnClickListener btnDeleteListener = new View.OnClickListener()
//    {
//        public void onClick(View v)
//        {
//            //Toast.makeText(getApplicationContext(), "삭제 버튼 클릭 테스트", Toast.LENGTH_LONG).show();
//            //해당 파일을 디스크 상에서 삭제, true 리턴 시 삭제 성공
//            boolean bDel = deleteFile(fileName_content);
//            boolean bDel2= deleteFile(fileName_location);
//            boolean bDel3=deleteFile(fileName_weather);
//            if(bDel&&bDel2&&bDel3)
//                Toast.makeText(getApplicationContext(), "메모 삭제 완료", Toast.LENGTH_LONG).show();
//            else
//                Toast.makeText(getApplicationContext(), "메모 삭제 실패", Toast.LENGTH_LONG).show();
//        }
//    };

    //백버튼 두번 연속 입력으로 종료 처리
    @Override
    public void onBackPressed()
    {
        if(System.currentTimeMillis() - backPressTime >= 2000)
        {
            backPressTime = System.currentTimeMillis();
            Toast.makeText(getApplicationContext(), "백(Back) 버튼을 한 번 더 누르면 종료", Toast.LENGTH_LONG).show();
        }
        else if(System.currentTimeMillis() - backPressTime < 2000)
            finish();
    }



















}