package com.example.diary1;

import android.app.AlertDialog;
import android.app.Application;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.error.VolleyError;
import com.android.volley.request.SimpleMultiPartRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TalkAdapter extends BaseAdapter {
    int check;
    LayoutInflater inflater;
    ArrayList<TalkItem> talkItems;

    isLogin_check login=new isLogin_check();

    public TalkAdapter(LayoutInflater inflater, ArrayList<TalkItem> talkItems) {
        this.inflater = inflater;
        this.talkItems = talkItems;
    }

    @Override
    public int getCount() {
        return talkItems.size();
    }

    @Override
    public Object getItem(int position) {
        return talkItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        if(view==null){
            view= inflater.inflate(R.layout.list_item, viewGroup, false);
        }

        TextView tvName= view.findViewById(R.id.tv_name);
        TextView tvDate= view.findViewById(R.id.tv_date);
        TextView tvMsg= view.findViewById(R.id.tv_msg);
        ImageView iv= view.findViewById(R.id.iv);
        Button button=view.findViewById(R.id.button4);
        TextView nickname=view.findViewById(R.id.textView11);

        TalkItem talkItem= talkItems.get(position);
        tvName.setText(talkItem.getName());
        tvDate.setText(talkItem.getDate());
        tvMsg.setText(talkItem.getMsg());
        nickname.setText(talkItem.getNickname());
        String img= talkItem.getImgPath();
        //네트워크에 있는 이미지 읽어오기.
        Glide.with(view).load(talkItem.getImgPath()).into(iv);

        String serverUrl="http://lsvk9921.cafe24.com/delete.php";


        //게시물 삭제버튼
        button.setOnClickListener(new View.OnClickListener() {
            String nickname=talkItem.getNickname();
            String nickname2=login.getName();
            @Override
            public void onClick(View view) {
                SimpleMultiPartRequest smpr= new SimpleMultiPartRequest(Request.Method.POST, serverUrl, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        new AlertDialog.Builder(view.getContext()).setMessage("업로드 성공!").create().show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(view.getContext(), "ERROR", Toast.LENGTH_SHORT).show();
                    }
                });
                if(nickname.equals(nickname2)) {
                    smpr.addStringParam("no", Integer.toString(talkItem.no));
                    Toast.makeText(view.getContext(), Integer.toString(talkItem.no), Toast.LENGTH_LONG).show();
                    //new AlertDialog.Builder(view.getContext()).setMessage(talkItem.getNo()).create().show();
                    //요청객체를 서버로 보낼 우체통 같은 객체 생성
                    RequestQueue requestQueue = Volley.newRequestQueue(view.getContext());
                    requestQueue.add(smpr);
                }else{
                    Toast.makeText(view.getContext(),"글쓴이가 아닙니다.",Toast.LENGTH_SHORT).show();
                    Toast.makeText(view.getContext(),nickname,Toast.LENGTH_SHORT).show();
                    Toast.makeText(view.getContext(),nickname2,Toast.LENGTH_SHORT).show();
                }

            }
        });


        return view;
    }
}